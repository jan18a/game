package game.engine;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.PriorityQueue;

import game.engine.base.Wall;
import game.engine.dataloader.DataLoader;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.exceptions.InvalidLaneException;
import game.engine.lanes.Lane;
import game.engine.titans.PureTitan;
import game.engine.titans.Titan;
import game.engine.titans.TitanRegistry;
import game.engine.weapons.factory.FactoryResponse;
import game.engine.weapons.factory.WeaponFactory;

public class Battle
{
	private static final int[][] PHASES_APPROACHING_TITANS =
	{
		{ 1, 1, 1, 2, 1, 3, 4 },
		{ 2, 2, 2, 1, 3, 3, 4 },
		{ 4, 4, 4, 4, 4, 4, 4 } 
	}; // order of the types of titans (codes) during each phase
	private static final int WALL_BASE_HEALTH = 10000;

	private int numberOfTurns;
	private int resourcesGathered;
	private BattlePhase battlePhase;
	private int numberOfTitansPerTurn; // initially equals to 1
	private int score; // Number of Enemies Killed
	private int titanSpawnDistance;
	private final WeaponFactory weaponFactory;
	private final HashMap<Integer, TitanRegistry> titansArchives;
	private final ArrayList<Titan> approachingTitans; // treated as a Queue
	private final PriorityQueue<Lane> lanes;
	private final ArrayList<Lane> originalLanes;

	public Battle(int numberOfTurns, int score, int titanSpawnDistance, int initialNumOfLanes,
			int initialResourcesPerLane) throws IOException
	{
		super();
		this.numberOfTurns = numberOfTurns;
		this.battlePhase = BattlePhase.EARLY;
		this.numberOfTitansPerTurn = 1;
		this.score = score;
		this.titanSpawnDistance = titanSpawnDistance;
		this.resourcesGathered = initialResourcesPerLane * initialNumOfLanes;
		this.weaponFactory = new WeaponFactory();
		this.titansArchives = DataLoader.readTitanRegistry();
		this.approachingTitans = new ArrayList<Titan>();
		this.lanes = new PriorityQueue<>();
		this.originalLanes = new ArrayList<>();
		this.initializeLanes(initialNumOfLanes);
	}

	public int getNumberOfTurns()
	{
		return numberOfTurns;
	}

	public void setNumberOfTurns(int numberOfTurns)
	{
		this.numberOfTurns = numberOfTurns;
	}

	public int getResourcesGathered()
	{
		return resourcesGathered;
	}

	public void setResourcesGathered(int resourcesGathered)
	{
		this.resourcesGathered = resourcesGathered;
	}

	public BattlePhase getBattlePhase()
	{
		return battlePhase;
	}

	public void setBattlePhase(BattlePhase battlePhase)
	{
		this.battlePhase = battlePhase;
	}

	public int getNumberOfTitansPerTurn()
	{
		return numberOfTitansPerTurn;
	}

	public void setNumberOfTitansPerTurn(int numberOfTitansPerTurn)
	{
		this.numberOfTitansPerTurn = numberOfTitansPerTurn;
	}

	public int getScore()
	{
		return score;
	}

	public void setScore(int score)
	{
		this.score = score;
	}

	public int getTitanSpawnDistance()
	{
		return titanSpawnDistance;
	}

	public void setTitanSpawnDistance(int titanSpawnDistance)
	{
		this.titanSpawnDistance = titanSpawnDistance;
	}

	public WeaponFactory getWeaponFactory()
	{
		return weaponFactory;
	}

	public HashMap<Integer, TitanRegistry> getTitansArchives()
	{
		return titansArchives;
	}

	public ArrayList<Titan> getApproachingTitans()
	{
		return approachingTitans;
	}

	public PriorityQueue<Lane> getLanes()
	{
		return lanes;
	}

	public ArrayList<Lane> getOriginalLanes()
	{
		return originalLanes;
	}

	private void initializeLanes(int numOfLanes)
	{
		for (int i = 0; i < numOfLanes; i++)
		{
			Wall w = new Wall(WALL_BASE_HEALTH);
			Lane l = new Lane(w);

			this.getOriginalLanes().add(l);
			this.getLanes().add(l);
		}
	}
	
	public void refillApproachingTitans(){
		if (this.getApproachingTitans().isEmpty()){
			switch (this.getBattlePhase()){
			case EARLY:
				int[] phase1= PHASES_APPROACHING_TITANS[0];
				for (int i=0; i<phase1.length;i++){
					TitanRegistry tr = titansArchives.get(phase1[i]);
					approachingTitans.add(tr.spawnTitan(this.titanSpawnDistance));	
				}
				
			case INTENSE: 
				int[] phase2= PHASES_APPROACHING_TITANS[1];
				for (int i=0; i<phase2.length;i++){
					TitanRegistry tr = titansArchives.get(phase2[i]);
					approachingTitans.add(tr.spawnTitan(this.titanSpawnDistance));	
				}
			case GRUMBLING:
				int[] phase3= PHASES_APPROACHING_TITANS[2];
				for (int i=0; i<phase3.length;i++){
					TitanRegistry tr = titansArchives.get(phase3[i]);
					approachingTitans.add(tr.spawnTitan(this.titanSpawnDistance));	
				}
			
			}
		}
	}
	
	public void purchaseWeapon(int weaponCode, Lane lane) throws InsufficientResourcesException,
	InvalidLaneException{
		if (!lane.isLaneLost()){
			FactoryResponse fr = weaponFactory.buyWeapon(this.resourcesGathered,weaponCode);
			setResourcesGathered(fr.getRemainingResources()); 
			lane.addWeapon(fr.getWeapon());
			performTurn(); 
		}
		throw new InvalidLaneException();
		
		
	}
	
	public void passTurn(){
		performTurn();
		
	}
	
	private void addTurnTitansToLane(){
		if (this.getApproachingTitans().isEmpty())
			refillApproachingTitans(); 
		else{
			switch(battlePhase){
			case EARLY:
				setNumberOfTitansPerTurn(1);
				setNumberOfTurns(1);
				Lane L = lanes.remove(); 
				L.addTitan(getApproachingTitans().remove(0));
				lanes.add(L); 
			case INTENSE: 
				    setNumberOfTitansPerTurn(1);
					while(numberOfTurns<=16){
					setNumberOfTurns(numberOfTurns++);
					Lane L2 = lanes.remove(); 
					L2.addTitan(getApproachingTitans().remove(0));
					lanes.add(L2);
					}	
			case GRUMBLING:
				setNumberOfTitansPerTurn(1);
					while(numberOfTurns<=46){
					setNumberOfTurns(numberOfTurns++);
					Lane L3 = lanes.remove(); 
					L3.addTitan(getApproachingTitans().remove(0));
					lanes.add(L3); 
					}
				setNumberOfTitansPerTurn(2);
					int i=0; 
					while(numberOfTurns<=81){
						setNumberOfTurns(numberOfTurns++);
					if (i%5==0 && i!=0){
						numberOfTitansPerTurn= numberOfTitansPerTurn*2;
					}
					for (int j=0; j<getNumberOfTitansPerTurn(); j++){
						Lane L3 = lanes.remove(); 
						L3.addTitan(getApproachingTitans().remove(0));
						lanes.add(L3);
					}			
					}
				
			}			
		}
	}
	
	private void moveTitans(){
		ArrayList<Lane> x = new ArrayList<Lane>(lanes.size()); 
		while (!lanes.isEmpty()){
			x.add(lanes.remove());
		}
		for (int i=0; i<x.size();i++){
			Lane tmp = x.get(i); 
			if (!tmp.getTitans().isEmpty()){
				tmp.moveLaneTitans();
			}
		lanes.add(tmp); 
		}
	}

	
	private int performWeaponsAttacks(){
		int resources =0; 
		ArrayList<Lane> x = new ArrayList<Lane>(); 
		while (!lanes.isEmpty()){
			x.add(lanes.remove());
		}
		for (int i=0; i<x.size();i++){
			if (!x.get(i).getWeapons().isEmpty()){
				resources= resources+x.get(i).performLaneWeaponsAttacks();
			}
		lanes.add(x.remove(i)); 
		}
		return resources; 
	}
	
	private int performTitansAttacks(){
		int resources =0; 
		ArrayList<Lane> x = new ArrayList<Lane>(lanes.size()); 
		while (!lanes.isEmpty()){
			x.add(lanes.remove());
		}
		for (int i=0; i<x.size();i++){
			if (!x.get(i).getTitans().isEmpty()){
				resources= resources+x.get(i).performLaneTitansAttacks();
			}
		lanes.add(x.remove(i)); 
		}
		return resources; 
	}
	
	private void updateLanesDangerLevels(){
		ArrayList<Lane> x = new ArrayList<Lane>(lanes.size()); 
		while (!lanes.isEmpty()){
			x.add(lanes.remove());
		}
		for (int i=0; i<x.size();i++){
			if (!x.get(i).getTitans().isEmpty()){
				x.get(i).updateLaneDangerLevel();
			}
		lanes.add(x.remove(i)); 
		}
	}
	private void finalizeTurns(){
		if(this.getNumberOfTurns()>=1 && this.getNumberOfTurns()<15){ 
			setBattlePhase(BattlePhase.EARLY);
			setNumberOfTitansPerTurn(1);
		}
		if(this.getNumberOfTurns()>=15 && this.getNumberOfTurns()<30){
			setBattlePhase(BattlePhase.INTENSE);
			setNumberOfTitansPerTurn(1);
		}
		if(this.getNumberOfTurns()>=30){
			setBattlePhase(BattlePhase.GRUMBLING);
			setNumberOfTitansPerTurn(getNumberOfTitansPerTurn()); 
			if(this.getNumberOfTurns()>30 && this.getNumberOfTurns()%5==0){
				setNumberOfTitansPerTurn(getNumberOfTitansPerTurn()*2);
			}
		}
			
	}
	
	
	/*private void finalizeTurns(){
		setNumberOfTurns(1);
			switch(getNumberOfTitansPerTurn()){
			case 1:
				 	
				}
			case INTENSE:
				setNumberOfTitansPerTurn(1); 
				if (getNumberOfTurns()<30 && !isGameOver()){
					int newTurn = getNumberOfTurns()+1; 
					setNumberOfTurns(newTurn); 	
					}
			case GRUMBLING:
				setNumberOfTitansPerTurn(getNumberOfTitansPerTurn());
				if (getNumberOfTurns()>=30 && !isGameOver()){
					if (getNumberOfTurns()%5==0 && getNumberOfTurns()!=30){
						setNumberOfTitansPerTurn(getNumberOfTitansPerTurn()*2); 
					}
					int newTurn = getNumberOfTurns()+1; 
					setNumberOfTurns(newTurn); 	
				}				
		}
	}*/
	
	private void performTurn(){
		moveTitans();
		setScore(performWeaponsAttacks());
		int TitanR = performTitansAttacks(); 
		addTurnTitansToLane(); 
		finalizeTurns();
		updateLanesDangerLevels(); 
	}
	
	public boolean isGameOver(){
		ArrayList<Lane> x = new ArrayList<Lane>(lanes.size()); 
		while (!lanes.isEmpty()){
			x.add(lanes.remove());
		}
		int j=0; 
		for (int i=0; i<x.size();i++){
			if (!x.get(i).isLaneLost())
				j++;	
		lanes.add(x.remove(i)); 
		}
		
		if (j==0){
			return true; 
		}
		else
			return false; 
	}

}
