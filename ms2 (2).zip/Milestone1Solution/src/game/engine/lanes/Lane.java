package game.engine.lanes;

import java.util.ArrayList;
import java.util.PriorityQueue;

import game.engine.base.Wall;
import game.engine.titans.Titan;
import game.engine.weapons.PiercingCannon;
import game.engine.weapons.SniperCannon;
import game.engine.weapons.VolleySpreadCannon;
import game.engine.weapons.WallTrap;
import game.engine.weapons.Weapon;

public class Lane implements Comparable<Lane>
{
	private final Wall laneWall;
	private int dangerLevel;
	private final PriorityQueue<Titan> titans;
	private final ArrayList<Weapon> weapons;

	public Lane(Wall laneWall)
	{
		super();
		this.laneWall = laneWall;
		this.dangerLevel = 0;
		this.titans = new PriorityQueue<>();
		this.weapons = new ArrayList<>();
	}

	public Wall getLaneWall()
	{
		return this.laneWall;
	}

	public int getDangerLevel()
	{
		return this.dangerLevel;
	}

	public void setDangerLevel(int dangerLevel)
	{
		this.dangerLevel = dangerLevel;
	}

	public PriorityQueue<Titan> getTitans()
	{
		return this.titans;
	}

	public ArrayList<Weapon> getWeapons()
	{
		return this.weapons;
	}

	@Override
	public int compareTo(Lane o)
	{
		return this.dangerLevel - o.dangerLevel;
	}
	
	public void addTitan(Titan titan){
		titans.add(titan); 
	}
	
	public void addWeapon(Weapon weapon){
		weapons.add(weapon); 
	}
	
	public void moveLaneTitans() {
		ArrayList<Titan> x = new ArrayList<Titan>();
		 while(!titans.isEmpty()) {
			 Titan temp =titans.remove();
			 if (!temp.hasReachedTarget()) {
				 temp.move();
				 x.add(temp);
				 }	 
			 
			 else
				 x.add(temp);
			 
		 }
		 for(int i=0;!x.isEmpty();i++) {
			 titans.add(x.remove(i));
	}
	}
	
	public int performLaneTitansAttacks(){
		int sum=0;
		ArrayList<Titan> x = new ArrayList<Titan>();
		while (!titans.isEmpty()){
			x.add(titans.remove()); 
		}
		for (int i=0; i<x.size();i++){
			Titan tmp = x.get(i); 
			if (tmp.hasReachedTarget() && !laneWall.isDefeated())
				sum+=tmp.attack(laneWall); 
			titans.add(tmp); 	
		}
		return sum; 
	}
		 
	/*public int performLaneTitansAttacks(){
		int sum=0; 
		ArrayList<Titan> x = new ArrayList<Titan>();
		 while(!titans.isEmpty()) {
			 Titan temp =titans.remove();
			 if (temp.hasReachedTarget()) {
				 temp.attack(laneWall);
				 sum+=laneWall.getResourcesValue(); 
				 x.add(temp);
				 }	 
			 else
				 x.add(temp); 
		 }
		 for(int i=0;!x.isEmpty();i++) {
			 titans.add(x.remove(i));
	}
		 return sum; 
}*/
	
	public int performLaneWeaponsAttacks(){
		int sum=0;
		for(int i=0; i<weapons.size();i++){	
			Weapon w = weapons.get(i); 
		if (w instanceof PiercingCannon){
			PiercingCannon tmp = new PiercingCannon(w.getDamage());
			sum+=tmp.turnAttack(titans);
		}
		if (w instanceof SniperCannon){
			SniperCannon tmp = new SniperCannon(w.getDamage());
			sum+=tmp.turnAttack(titans);
		}
		if (w instanceof VolleySpreadCannon){
			VolleySpreadCannon tmp = new VolleySpreadCannon(w.getDamage(), ((VolleySpreadCannon) w).getMinRange(), ((VolleySpreadCannon) w).getMaxRange());
			sum+=tmp.turnAttack(titans);
		}
		if (w instanceof WallTrap){
			WallTrap tmp = new WallTrap(w.getDamage());
			sum+=tmp.turnAttack(titans);
		}
		}
		return sum; 
		
	}
	
	 /*public int performLaneWeaponsAttacks(){
		int sum=0; 
		 for(int i=0; i<weapons.size();i++){
			if (weapons.get(i).getDamage()==10){
				PiercingCannon tmp = new PiercingCannon(weapons.get(i).getDamage());
				sum+=tmp.turnAttack(titans);
			}
			if (weapons.get(i).getDamage()==35){
				SniperCannon tmp = new SniperCannon(weapons.get(i).getDamage());
				sum+=tmp.turnAttack(titans);
			}
			if (weapons.get(i).getDamage()==5){
				VolleySpreadCannon tmp = new VolleySpreadCannon(weapons.get(i).getDamage(), 20, 50);
				sum+=tmp.turnAttack(titans);
			}
			if (weapons.get(i).getDamage()==100){
				WallTrap tmp = new WallTrap(weapons.get(i).getDamage());
				sum+=tmp.turnAttack(titans);
			}	
		 }
		 return sum; 
	 }*/
	 
	 public boolean isLaneLost(){
		 return (laneWall.isDefeated());
	 }
	
	 public void updateLaneDangerLevel(){
			ArrayList<Titan> x = new ArrayList<Titan>();
			 while(!titans.isEmpty()) {
				 Titan temp =titans.remove();
				 dangerLevel+=temp.getDangerLevel();
					 x.add(temp);

			 }
			 for(int i=0;!x.isEmpty();i++) {
				 titans.add(x.remove(i));
		}

	 }
	

}
