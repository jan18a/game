package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.ArrayList;
import java.util.PriorityQueue;

public class PiercingCannon extends Weapon
{
	public static final int WEAPON_CODE = 1;

	public PiercingCannon(int baseDamage)
	{
		super(baseDamage);
	}
	
	
	
	/*public ArrayList<Titan> Sort (ArrayList<Titan> titans){
		 ArrayList<Titan> result= new ArrayList<Titan>();
		
		for (int i=0; i<titans.size()-1; i++){
			Titan x=titans.get(i);
			for (int j=0; j<titans.size()-i-1; j++){
				Titan y=titans.get(j);
				if (x.getDistance()>y.getDistance()){
					Titan temp = x;
					x=y;
					y=temp;
					titans.add(x);
				}
				}
			result.add(x);
			
		}
		return result;
	}*/
	
	
	/*public int turnAttack(PriorityQueue<Titan> laneTitans){
		int sum=0; Titan s; 
		ArrayList<Titan> x = new ArrayList<Titan>(); 
		ArrayList<Titan> y = new ArrayList<Titan>(); 
		int  dis=-1;
		while(!laneTitans.isEmpty()){
			Titan tmp = laneTitans.remove(); 
			x.add(tmp); 	
		}
		for(int i=0; i<5;i++){
			Titan c= x.remove(i);
			for(int j=0; j<x.size();j++){
				Titan a= x.remove(j);
				if(c.getDistance()>a.getDistance()){
					Titan temp=c;
					c=a;
					a=temp;
				}	
			}
			sum+=attack(c);
			if (!c.isDefeated())
			y.add(c); 
				
			}
		for (int i=0; i<x.size(); i++){
			laneTitans.add(x.remove(i)); 
		}
		return sum; 
		
			
		}
		
	}*/
	
	public int turnAttack(PriorityQueue<Titan> laneTitans){
		int sum=0; 
		PriorityQueue<Titan> x = new PriorityQueue<Titan>(); 
		while( !laneTitans.isEmpty()){
			Titan tmp = laneTitans.remove(); 
			sum+=attack(tmp);
			if (!tmp.isDefeated())
			x.add(tmp); 	
		}
		while( !x.isEmpty()){
			laneTitans.add(x.remove()); 
		}
		return sum; 
		
	}

	//@Override
		/*public int turnAttack(PriorityQueue<Titan> laneTitans) {
			int sum=0;
			Titan [] x= new  Titan [5];
			for(int i=0; i<5 || laneTitans.isEmpty(); i++) {
				x[i]= laneTitans.remove();
			}
			for(int i=0; i<5; i++) {
				super.attack(x[i]);
			}
			for(int i=0; i<5; i++) {
				if(!x[i].isDefeated()) {
					laneTitans.add(x[i]);
				}
				else
					sum = sum + x[i].getResourcesValue();
			}
			return sum;
		}*/
	}


