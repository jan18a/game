package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.ArrayList;
import java.util.PriorityQueue;

public class WallTrap extends Weapon
{
	public static final int WEAPON_CODE = 4;

	public WallTrap(int baseDamage)
	{
		super(baseDamage);
	}
	
	public int turnAttack(PriorityQueue<Titan> laneTitans){
		int sum=0; 
		ArrayList<Titan> x = new ArrayList<>();
		while(!laneTitans.isEmpty()){
			x.add(laneTitans.remove()); 
		}
		for (int i=0; i<x.size(); i++){
			Titan tmp = x.get(i);
			if (x.get(i).hasReachedTarget()){ 
				attack(tmp); 
			}
			if (!x.get(i).isDefeated()){
				laneTitans.add(tmp); 
			}
			if (x.get(i).isDefeated())
				sum+=tmp.getResourcesValue();
		}
		return sum; 
	}
	}
		 

