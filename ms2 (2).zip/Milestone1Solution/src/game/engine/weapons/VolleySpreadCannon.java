package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.PriorityQueue;


public class VolleySpreadCannon extends Weapon
{
	public static final int WEAPON_CODE = 3;

	private final int minRange;
	private final int maxRange;

	public VolleySpreadCannon(int baseDamage, int minRange, int maxRange)
	{
		super(baseDamage);
		this.minRange = minRange;
		this.maxRange = maxRange;
	}

	public int getMinRange()
	{
		return minRange;
	}

	public int getMaxRange()
	{
		return maxRange;
	}
	
	/*public int turnAttack(PriorityQueue<Titan> laneTitans){
		int sum=0; 
		LinkedList<Titan> x= new LinkedList<Titan>();
		LinkedList<Titan> y= new LinkedList<Titan>();
		while(!laneTitans.isEmpty()) {
			 x.add(laneTitans.poll());
		 }
		while (!x.isEmpty()){
			Titan tmp = x.getFirst();
			if (tmp.getDistance()>=getMinRange() && tmp.getDistance()<=getMaxRange()){
				if (!tmp.isDefeated()){
					sum+=attack(tmp); 
					y.add(tmp); 
				}
				else
					x.remove(tmp);
			}
			if (!tmp.isDefeated())
				y.add(tmp); 
			
		
		}
		while (!y.isEmpty()){
			laneTitans.add(y.removeFirst());
		}
		return sum; 
 
	}*/
	
	/*public int turnAttack(PriorityQueue<Titan> laneTitans){
		PriorityQueue<Titan> newLT = new PriorityQueue<Titan>(); 
		int sum=0; 
			while(!laneTitans.isEmpty()){
				Titan tmp = laneTitans.poll();
				if (tmp.getDistance()>=getMinRange() && tmp.getDistance()<=getMaxRange()){
					 if (tmp.isDefeated())
						laneTitans.remove(tmp);
					 
					 else{
						 sum+=attack(tmp); 
						 newLT.add(tmp); 
					 }
			}
			if (!tmp.isDefeated())
			newLT.add(tmp);
		}
			while (!newLT.isEmpty()){
				laneTitans.add(newLT.poll()); 
			}
		return sum; 
		
	}*/
	
	
	/*public int turnAttack(PriorityQueue<Titan> laneTitans) {
		int sum=0;
		ArrayList<Titan> x = new ArrayList<Titan>();
		 while(!laneTitans.isEmpty()) {
			 Titan tmp = laneTitans.remove(); 
			 if (tmp.getDistance()>=getMinRange() && tmp.getDistance()<=getMaxRange()){
				 sum+=attack(tmp);
				 if (!tmp.isDefeated())
				 x.add(tmp); 
			 }
			 if (!tmp.isDefeated())
			 x.add(tmp); 
		 }
		 for(int i=0; i<x.size(); i++){
			 laneTitans.add(x.remove(i)); 
		 }
		 return sum;
	}*/
	
	public int turnAttack(PriorityQueue<Titan> laneTitans) {
		int sum=0;
		ArrayList<Titan> x = new ArrayList<Titan>(laneTitans.size());
			while(!laneTitans.isEmpty()){
				x.add(laneTitans.remove());
			}
			for (int i=0; i<x.size();i++){
				Titan tmp = x.get(i); 
				if (tmp.getDistance()>=getMinRange() && tmp.getDistance()<=getMaxRange()){
					sum+=attack(tmp); 
					if (tmp.isDefeated()){
					x.remove(tmp); 
					i-=1; 
					}
					else
					laneTitans.add(tmp); 
				}
				if (!tmp.isDefeated())
				laneTitans.add(tmp); 
			}
		 return sum;
	}

}
